<div class="container-fluid" id="fons">
    <br>
	<div id="container color">
		<!-- Creem un 'div', per al contingut de la pàgina -->
		<div id="fons2" class="container content inici" style="min-height: 480px;">
			<!-- Deixem una fila buida, perquè hi hagi separació entre el menú i el contingut de la pàgina -->
			<div class="row">
				<div class="col-xs-12">
					<br>
					<font size="6">
						<strong>
							<u>COMANDA</u>
						</strong>
						<br>
					</font>
					<ol class="bredcrumb pull-left"></ol>
				</div>
			</div>
			<!-- Creem una fila, que servirà per mostrar les diferents opcions que hi han per cada apartat del menú -->
			<!-- Al inici, per defecte, mostrarà un missatge de benvinguda -->
            <?php $totalPrice = 0; ?>
			<div align="center">
			<table align="center"> 
				<tr>
					<td width="3%">

					</td>
					<td width="25%" align="center"> 
						<font size="4">
							<strong>
								<?php echo e(trans('web.producto')); ?> (<?php echo e(trans('web.unidad2')); ?>)
							</strong>
						</font>
					</td>
					<td width="25%" align="center"> 
						<font size="4">
							<strong>
								<?php echo e(trans('web.cantidad')); ?> 
							</strong>
						</font>
					</ts>
					<td width="25%" align="center"> 
						<font size="4">
							<strong>
								<?php echo e(trans('web.total')); ?>

							</strong> 
						</font>
					</td>
				</tr>
            <?php $__empty_1 = true; $__currentLoopData = $productQuantities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $productQuantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $totalPrice += $products[$key]->price * $productQuantity; ?>
				<tr>
					<td width="3%">

					</td> 
                	<td align="center">
						<?php echo e($products[$key]->name); ?> (<?php echo e($products[$key]->price); ?> € / <?php echo e(trans('web.unidad')); ?>)
					</td>
					<td align="center">
						<?php echo e($productQuantity); ?>

					</td>
					<td align="center">
						<?php echo e($products[$key]->price * $productQuantity); ?> € 
					</td>
				</tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p><?php echo e(trans("web.products_not_found")); ?></p>
            <?php endif; ?>
			</table>
			</div>
				<hr>
			<div align="right" style="margin-right: 13%">
            	<font size="4"><strong><?php echo e(trans('web.total')); ?>:</strong> <?php echo e($totalPrice); ?> € </font> 
				<br><br>
				<?php echo e(Form::open(['route' => ['create_order'], 'method' => 'POST'])); ?>

				<?php echo e(Form::hidden('orderLines', serialize($productQuantities))); ?>

				<?php echo e(Form::label('franchise_id', trans("web.franchise").":")); ?>

				<div class="form-group col-lg-offset-9 col-lg-4">
					<?php echo e(Form::select("franchise_id", $franchises->pluck("address", "id"), Auth::user()->franchise_id,
						array("placeholder" => trans("web.select_franchise"),
						"class" => "form-control"))); ?>

					<?php
						if ($errors->has('franchise_id')) {
							echo "<div style='color: #ff0000'>".$errors->first('franchise_id')."</div>";
						}
					?>
				</div>
				<div class="form-group">
					<?php echo e(Form::submit(trans("web.confirmar"), ["class" => "btn btn-primary"])); ?>

				</div>
			<?php echo e(Form::close()); ?>

			</div>
	    </div>
	</div>
	<br>
</div><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/frontend/cart/cos.blade.php ENDPATH**/ ?>