<head>	
	<?php echo $__env->make('frontend.arxius.arxius', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<div class="container-fluid" id="fons">
    <header>
		<?php echo $__env->make('frontend.desserts.capcalera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</header>
	<div id="container color">
		<!-- Creem un 'div', per al contingut de la pàgina -->
		<div id="fons2" class="container content inici" style="min-height: 480px;">
			<!-- Deixem una fila buida, perquè hi hagi separació entre el menú i el contingut de la pàgina -->
			<div class="row">
				<div class="col-xs-12">
					<ol class="bredcrumb pull-left"></ol>
				</div>
			</div>
			<!-- Creem una fila, que servirà per mostrar les diferents opcions que hi han per cada apartat del menú -->
			<!-- Al inici, per defecte, mostrarà un missatge de benvinguda -->
            <?php $totalPrice = 0; ?>
            <?php $__empty_1 = true; $__currentLoopData = $productQuantities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $productQuantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $totalPrice += $products[$key]->price * $productQuantity; ?>
                <p><?php echo e($products[$key]->name); ?> x <?php echo e($productQuantity); ?> = <?php echo e($products[$key]->price * $productQuantity); ?> €</p>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p><?php echo e(trans("web.products_not_found")); ?></p>
            <?php endif; ?>
                <p>Total: <?php echo e($totalPrice); ?> € </p>
	    </div>
        <br>
	</div>
</div><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/frontend/cart/tiquet.blade.php ENDPATH**/ ?>