<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.order_details")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container-fluid" id="fons">
    <br>
	<div id="container color">
	<div id="fons2" class="container content inici" style="min-height: 480px;">
	<?php if(!$order): ?>
		<br>
		<p><?php echo e(trans("web.orders_not_found")); ?></p>
	<?php else: ?>
		<div class="col-sm-12">
			<br>
			<font size="5"><?php echo e(trans("web.order_details")); ?></font>
			<table class="table table-striped table-bordered table-hover">
				<tr>
					<td class="w-25" align="center">
						<font size="4">
							<strong><?php echo e(trans("web.code")); ?></strong>
						</font>
					</td>
					<td><?php echo e($order->id); ?></td>
				</tr>
				<tr>
					<td class="w-25" align="center">
						<font size="4">
							<strong><?php echo e(trans("web.franchise")); ?></strong>
						</font>
					</td>
					<td><?php echo e($order->franchise->name); ?></td>
				</tr>
				<tr>
					<td class="w-25" align="center">
						<font size="4">
							<strong><?php echo e(trans("web.address")); ?></strong>
						</font>
					</td>
					<td>
						<?php echo e($order->franchise->address); ?>

					</td>
				</tr>
				<tr>
					<td class="w-25" align="center">
						<font size="4">
							<strong><?php echo e(trans("web.state")); ?></strong>
						</font>
					</td>
					<td>
						<?php echo e($order->orderstate->name); ?>

					</td>
				</tr>
			</table>
		</div>
		<div class="col-sm-12">
			<font size="5"><?php echo e(trans("web.state_history")); ?></font>
			<table class="table table-striped table-bordered table-hover">
				<tr>
					<td align="center">
						<font size="4">
							<strong><?php echo e(trans("web.state")); ?></strong>
						</font>
					</td>
					<td align="center">
						<font size="4">
							<strong><?php echo e(trans("web.date")); ?></strong>
						</font>
					</td>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $order->orderstate_history()->orderBy("created_at", "desc")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td align="center"><?php echo e($order_state->ordestate->name); ?></td>
						<td><?php echo e($order_state->created_at); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<td colspan=2>
						<br>
						<?php echo e(trans("web.order_lines_not_found")); ?>

					</td>
				<?php endif; ?>
			</table>
		</div>
		<div class="col-sm-12">
			<br>
			<font size="5"><?php echo e(trans("web.order_lines")); ?></font>
			<table class="table table-striped table-bordered table-hover">
				<tr>
					<td align="center">
						<font size="4">
							<strong><?php echo e(trans("web.quantity")); ?></strong>
						</font>
					</td>
					<td align="center">
						<font size="4">
							<strong><?php echo e(trans("web.product")); ?></strong>
						</font>
					</td>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $order->order_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td class="w-25" align="center"><?php echo e($order_line->quantify); ?></td>
						<td><?php echo e($order_line->product->name); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<td colspan=2 align="center">
						<br>
						<?php echo e(trans("web.order_lines_not_found")); ?>

						<br><br>
					</td>
				<?php endif; ?>
			</table>
		</div>
	<?php endif; ?>
	</div>
	<br>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/frontend/orders/o.blade.php ENDPATH**/ ?>