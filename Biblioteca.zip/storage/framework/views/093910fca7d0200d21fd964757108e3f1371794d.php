
<?php echo $__env->make('frontend.LlibresCategoria.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\biblioteca\resources\views/frontend/llibresCategoria/cataleg.blade.php ENDPATH**/ ?>