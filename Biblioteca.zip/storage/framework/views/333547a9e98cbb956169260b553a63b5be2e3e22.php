
							<br>
                            <font size="4">
							    <strong><?php echo e($llibres->nom); ?></strong>
                            </font>
							<br>
							<font size="4">
							    <strong><?php echo e($llibres->autor); ?></strong>
                            </font>
							<br>
							<font size="4">
							    <strong><?php echo e($llibres->editorial); ?></strong>
                            </font>
							<br>
							<font size="4">
							    <strong><?php echo e($llibres->preu); ?></strong>
                            </font><?php /**PATH C:\xampp\htdocs\biblioteca\resources\views/frontend/llibresCategoria/cos.blade.php ENDPATH**/ ?>