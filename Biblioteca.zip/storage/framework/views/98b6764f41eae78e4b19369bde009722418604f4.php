
		<header>
			<?php echo $__env->make('frontend.LlibresCategoria.capcalera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</header>
		<script src="js/menu.js"></script>
		<?php echo $__env->make('frontend.LlibresCategoria.cos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\biblioteca\resources\views/frontend/LlibresCategoria/menu.blade.php ENDPATH**/ ?>