<head>	
	<?php echo $__env->make('frontend.arxius.arxius', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="cursor:default">
	<!-- Creem un 'div', per a la capçalera de la pàgina -->
	<div id="container-fluid" align="center">
		<header>
			<?php echo $__env->make('frontend.drinks.capcalera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</header>
		<script src="js/menu.js"></script>
		<?php echo $__env->make('frontend.drinks.cos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<?php echo $__env->make('frontend.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/frontend/drinks/menu.blade.php ENDPATH**/ ?>