
		<header>
			<?php echo $__env->make('frontend.llibresIVA.capcalera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</header>
		<script src="js/menu.js"></script>
		<?php echo $__env->make('frontend.llibresIVA.cos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Prova-de-nivell\resources\views/frontend/llibresIVA/menu.blade.php ENDPATH**/ ?>