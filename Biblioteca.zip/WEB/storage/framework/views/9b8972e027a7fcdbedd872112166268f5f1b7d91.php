<div class="input-group searchBar">
    <input type="text" class="form-control" placeholder="<?php echo e(trans('web.search_by_name')); ?>">
    <div class="input-group-append">
        <button class="btn btn-secondary" type="button">
            <i class="fa fa-search"></i>
        </button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/partials/backend_searchbar.blade.php ENDPATH**/ ?>