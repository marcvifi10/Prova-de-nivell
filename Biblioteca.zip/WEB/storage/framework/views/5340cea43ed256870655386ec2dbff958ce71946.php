
<?php echo $__env->make('frontend.llibres.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Prova-de-nivell\resources\views/frontend/llibres/cataleg.blade.php ENDPATH**/ ?>