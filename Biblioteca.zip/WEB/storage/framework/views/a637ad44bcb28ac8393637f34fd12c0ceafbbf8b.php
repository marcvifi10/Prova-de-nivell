
		<header>
			<?php echo $__env->make('frontend.llibresInferiors15.capcalera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</header>
		<script src="js/menu.js"></script>
		<?php echo $__env->make('frontend.llibresInferiors15.cos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Prova-de-nivell\WEB\resources\views/frontend/llibresInferiors15/menu.blade.php ENDPATH**/ ?>