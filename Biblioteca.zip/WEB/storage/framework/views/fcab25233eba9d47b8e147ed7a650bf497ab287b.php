<div class="container-fluid" id="fons">
    <br>
	<div id="container color">
		<!-- Creem un 'div', per al contingut de la pàgina -->
		<div id="fons2" class="container content inici" style="min-height: 480px;">
			<!-- Deixem una fila buida, perquè hi hagi separació entre el menú i el contingut de la pàgina -->
			<div class="row">
				<div class="col-xs-12">
					<ol class="bredcrumb pull-left"></ol>
				</div>
			</div>
			<!-- Creem una fila, que servirà per mostrar les diferents opcions que hi han per cada apartat del menú -->
			<!-- Al inici, per defecte, mostrarà un missatge de benvinguda -->
			<div class="row">
				<!-- Determinem la posició del menú -->
					<?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
							<img src="<?php echo e($drink->imatge); ?>" width="70%" id="<?php echo e($drink->name); ?>">
							<br>
							<font size="4"> 
							    <strong><?php echo e($drink->name); ?></strong>
                            </font>
							<br>
							<?php echo e($drink->price); ?> €
							<br>
							<a role="button" href="<?php echo e(route('add_product',$drink->id)); ?>" class="btn btn-primary" name="afegir"><i class="fas fa-shopping-cart"></i><?php echo e(trans("web.anadir")); ?></a>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div> 
				<br>
			</div>
			<br> 
		</div>
	</div>
</div>			<?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/frontend/drinks/cos.blade.php ENDPATH**/ ?>