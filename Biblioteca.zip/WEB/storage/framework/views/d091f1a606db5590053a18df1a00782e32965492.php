
		<header>
			<?php echo $__env->make('frontend.llibres.capcalera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</header>
		<script src="js/menu.js"></script>
		<?php echo $__env->make('frontend.llibres.cos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Prova-de-nivell\resources\views/frontend/llibres/menu.blade.php ENDPATH**/ ?>