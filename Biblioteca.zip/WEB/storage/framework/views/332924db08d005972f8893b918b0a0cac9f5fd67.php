<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.franchises")); ?>

<?php $__env->stopSection(); ?>

<?php
	if (isset($_GET["search"]) && !empty($_GET["search"])) {
		$franchises = $franchises->reject(function ($franchise) {
                        return stripos($franchise->name, $_GET["search"]) === false;
                    });
	}
?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('js/confirm_delete.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/update_content_search.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("style"); ?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css"
	integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ"
	crossorigin="anonymous">
<link href="<?php echo e(asset('css/backend_index.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-2">
            <a href="<?php echo e(route('admin.franchises.create')); ?>" class="btn btn-primary" role="button">
                <span class="buttonText"><?php echo e(trans("web.create")); ?></span>
            </a>
        </div>
        <div class="col-sm-10">
            <?php echo $__env->make("partials.backend_searchbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
	<div class="row" id="content">
        <div class="col-sm-12">
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th><?php echo e(trans("web.name")); ?></th>
                        <th><?php echo e(trans("web.address")); ?></th>
                        <th><?php echo e(trans("web.phone")); ?></th>
                        <th><?php echo e(trans("web.email")); ?></th>
                        <th><?php echo e(trans("web.coordinates")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $franchises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franchise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.franchises.show', $franchise->id)); ?>">
                                <?php echo e($franchise->name); ?>

                            </a>
                        </td>
                        <td><?php echo e($franchise->address); ?></td>
                        <td><?php echo e($franchise->phone); ?></td>
                        <td><?php echo e($franchise->email); ?></td>
                        <td><?php echo e($franchise->coordinates); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.franchises.edit', $franchise->id)); ?>" class="btn btn-primary" role="button">
                                <?php echo e(trans("web.edit")); ?>

                            </a>
                        </td>
                        <td>
                            <?php echo e(Form::open(['route' => ['admin.franchises.destroy', $franchise->id],
                                'method' => 'DELETE', "class" => "deleteForm"])); ?>

                            <?php echo e(Form::submit(trans("web.delete"), ["class" => "btn btn-danger",
                                "data-text" => trans("web.confirm_delete")])); ?>

                            <?php echo e(Form::close()); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan=5><?php echo e(trans("web.franchises_not_found")); ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/franchises/index.blade.php ENDPATH**/ ?>