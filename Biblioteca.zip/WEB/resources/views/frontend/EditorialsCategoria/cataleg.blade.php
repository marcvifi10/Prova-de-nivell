@extends('layouts.app')

@extends('frontend.EditorialsCategoria.menu')