@extends('layouts.app')

@extends('frontend.editorials.menu')