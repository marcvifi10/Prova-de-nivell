@extends('layouts.app')

@include('frontend.login.plantilla')

