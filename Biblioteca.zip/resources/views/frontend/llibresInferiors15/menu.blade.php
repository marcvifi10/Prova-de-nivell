
		<header>
			@include('frontend.llibresInferiors15.capcalera')
		</header>
		<script src="js/menu.js"></script>
		@include('frontend.llibresInferiors15.cos')
