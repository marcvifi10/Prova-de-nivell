
		<header>
			@include('frontend.llibres.capcalera')
		</header>
		<script src="js/menu.js"></script>
		@include('frontend.llibres.cos')
