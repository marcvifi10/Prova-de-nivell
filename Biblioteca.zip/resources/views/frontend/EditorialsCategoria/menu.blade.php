
		<header>
			@include('frontend.EditorialsCategoria.capcalera')
		</header>
		<script src="js/menu.js"></script>
		@include('frontend.EditorialsCategoria.cos')
