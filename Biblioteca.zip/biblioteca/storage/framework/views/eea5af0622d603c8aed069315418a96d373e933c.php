<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.users")); ?>

<?php $__env->stopSection(); ?>

<?php
	if (isset($_GET["search"]) && !empty($_GET["search"])) {
		$users = $users->reject(function ($user) {
                        return stripos($user->name, $_GET["search"]) === false;
                    });
	}
?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('js/confirm_delete.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/update_content_search.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("style"); ?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css"
	integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ"
	crossorigin="anonymous">
<link href="<?php echo e(asset('css/backend_index.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <?php echo $__env->make("partials.backend_searchbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
	<div class="row" id="content">
        <div class="col-sm-12">
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th><?php echo e(trans("web.name")); ?></th>
                        <th><?php echo e(trans("web.address")); ?></th>
                        <th><?php echo e(trans("web.email")); ?></th>
                        <th><?php echo e(trans("web.user_type")); ?></th>
                        <th><?php echo e(trans("web.franchise")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $user->id)); ?>">
                                <?php echo e($user->name); ?>

                            </a>
                        </td>
                        <td><?php echo e($user->address); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->typeuser->name); ?></td>
                        <td><?php echo e($user->franchise->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-primary" role="button">
                                <?php echo e(trans("web.edit")); ?>

                            </a>
                        </td>
                        <?php if($user->id != Auth::user()->id): ?>
                            <td>
                                <?php echo e(Form::open(['route' => ['admin.users.destroy', $user->id],
                                    'method' => 'DELETE', "class" => "deleteForm"])); ?>

                                <?php echo e(Form::submit(trans("web.delete"), ["class" => "btn btn-danger",
                                    "data-text" => trans("web.confirm_delete")])); ?>

                                <?php echo e(Form::close()); ?>

                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan=5><?php echo e(trans("web.users_not_found")); ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/users/index.blade.php ENDPATH**/ ?>