<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.menus")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('js/confirm_delete.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
	<div class="col-sm-12">
		<a href="<?php echo e(route('admin.menus.create')); ?>" class="btn btn-primary" role="button">
			<?php echo e(trans("web.create")); ?>

		</a>
	</div>
	<div class="col-sm-12">  
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th><?php echo e(trans("web.name")); ?></th>
					<th><?php echo e(trans("web.price")); ?></th>
					<th><?php echo e(trans("web.description")); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr>
					<td>
                        <a href="<?php echo e(route('admin.menus.show', $menu->id)); ?>">
                            <?php echo e($menu->name); ?>

                        </a>
                    </td>
					<td><?php echo e($menu->price); ?></td>
					<td class="w-50"><?php echo e($menu->description); ?></td>
					<td>
                        <a href="<?php echo e(route('admin.menus.edit', $menu->id)); ?>" class="btn btn-primary" role="button">
                            <?php echo e(trans("web.edit")); ?>

                        </a>
                    </td>
                    <td>
						<?php echo e(Form::open(['route' => ['admin.menus.destroy', $menu->id],
							'method' => 'DELETE', "class" => "deleteForm"])); ?>

						<?php echo e(Form::submit(trans("web.delete"), ["class" => "btn btn-danger",
							"data-text" => trans("web.confirm_delete")])); ?>

                        <?php echo e(Form::close()); ?>

                    </td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<tr>
					<td colspan=3><?php echo e(trans("web.menus_not_found")); ?></td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/menus/index.blade.php ENDPATH**/ ?>