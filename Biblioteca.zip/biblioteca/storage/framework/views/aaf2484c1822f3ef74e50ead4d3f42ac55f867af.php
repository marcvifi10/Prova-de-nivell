<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.dashboard")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("style"); ?>
<link href="<?php echo e(asset('css/stretched_link.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/order_states.css')); ?>" rel="stylesheet">
<style>
	.card {
		margin-top: 10px;
	}
	.table {
		margin-bottom: 0px;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('js/refresh_page.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
	<div class="row">
		<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
				<div class="card text-center">
					<a href="<?php echo e(route('franchise.nextState', $order->id)); ?>" class="stretched-link"></a>
					<div class="card-header">
						<div class="col-sm-12">
							<?php echo e(trans("web.client")); ?>: <?php echo e($order->user->name); ?>

						</div>
						<div class="col-sm-12">
							<?php echo e(trans("web.address")); ?>: <?php echo e($order->user->address); ?>

						</div>
					</div>
					<div class="card-body <?php echo e(strtolower($order->orderstate->name)); ?>">
						<div class="col-sm-12">
							<p><?php echo e(trans("web.order_state")); ?>:</p>
							<h2><?php echo e($order->orderstate->name); ?></h2>
						</div>
					</div>
					<div>
						<table class="table table-striped table-bordered table-hover">
							<?php $__empty_2 = true; $__currentLoopData = $order->order_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
								<tr>
									<td class="w-25"><?php echo e($order_line->quantify); ?></td>
									<td><?php echo e($order_line->product->name); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
								<tr><td><?php echo e(trans("web.order_lines_not_found")); ?></td></tr>
							<?php endif; ?>
						</table>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<p><?php echo e(trans("web.orders_not_found")); ?></p>
		<?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/franchises/dashboard.blade.php ENDPATH**/ ?>