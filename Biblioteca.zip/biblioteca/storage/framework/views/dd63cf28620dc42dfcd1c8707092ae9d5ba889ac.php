<nav class="navbar navbar-expand bg-dark navbar-dark">
	<ul class="navbar-nav mr-auto">
		<?php if(Auth::user()->typeuser->name == "admin"): ?>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
					<?php echo e(trans("web.dashboard")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.franchises.index')); ?>">
					<?php echo e(trans("web.franchises")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.products.index')); ?>">
					<?php echo e(trans("web.products")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.product_categories.index')); ?>">
					<?php echo e(trans("web.product_categories")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.ingredients.index')); ?>">
					<?php echo e(trans("web.ingredients")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.ingredient_categories.index')); ?>">
					<?php echo e(trans("web.ingredient_categories")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.menus.index')); ?>">
					<?php echo e(trans("web.menus")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>">
					<?php echo e(trans("web.users")); ?>

				</a>
			</li>
		<?php elseif(Auth::user()->typeuser->name == "franchise"): ?>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('franchise.dashboard')); ?>">
					<?php echo e(trans("web.dashboard")); ?>

				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('franchise.orders')); ?>">
					<?php echo e(trans("web.orders")); ?>

				</a>
			</li>
		<?php endif; ?>
	</ul>
	<ul class="navbar-nav ml-auto">
		<li class="nav-item">
			<a class="nav-link" href="<?php echo e(route('logout')); ?>">
				<?php echo e(trans("web.logout")); ?>

			</a>
		</li>
	</ul>
</nav><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/partials/backend_menu.blade.php ENDPATH**/ ?>