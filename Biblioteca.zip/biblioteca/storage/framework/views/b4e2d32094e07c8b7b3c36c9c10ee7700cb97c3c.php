<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.dashboard")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("style"); ?>
<link href="<?php echo e(asset('css/stretched_link.css')); ?>" rel="stylesheet">
<style>
	.card {
		margin-top: 10px;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-4">
			<div class="card text-center">
				<a href="<?php echo e(route('admin.franchises.index')); ?>" class="stretched-link"></a>
				<div class="card-header">
					<?php echo e(trans("web.franchises")); ?>

				</div>
				<div class="card-body">
					<?php echo e($data["franchises"]); ?>

				</div> 
			</div>
		</div>
		<div class="col-sm-4">
			<div class="card text-center">
				<a href="<?php echo e(route('admin.products.index')); ?>" class="stretched-link"></a>
				<div class="card-header">
					<?php echo e(trans("web.products")); ?>

				</div>
				<div class="card-body">
					<?php echo e($data["products"]); ?>

				</div> 
			</div>
		</div>
		<div class="col-sm-4">
			<div class="card text-center">
				<a href="<?php echo e(route('admin.product_categories.index')); ?>" class="stretched-link"></a>
				<div class="card-header">
					<?php echo e(trans("web.product_categories")); ?>

				</div>
				<div class="card-body">
					<?php echo e($data["product_categories"]); ?>

				</div> 
			</div>
		</div>
		<div class="col-sm-4">
			<div class="card text-center">
				<a href="<?php echo e(route('admin.ingredients.index')); ?>" class="stretched-link"></a>
				<div class="card-header">
					<?php echo e(trans("web.ingredients")); ?>

				</div>
				<div class="card-body">
					<?php echo e($data["ingredients"]); ?>

				</div> 
			</div>
		</div>
		<div class="col-sm-4">
			<div class="card text-center">
				<a href="<?php echo e(route('admin.ingredient_categories.index')); ?>" class="stretched-link"></a>
				<div class="card-header">
					<?php echo e(trans("web.ingredient_categories")); ?>

				</div>
				<div class="card-body">
					<?php echo e($data["ingredient_categories"]); ?>

				</div> 
			</div>
		</div>
		<div class="col-sm-4">
			<div class="card text-center">
				<a href="<?php echo e(route('admin.menus.index')); ?>" class="stretched-link"></a>
				<div class="card-header">
					<?php echo e(trans("web.menus")); ?>

				</div>
				<div class="card-body">
					<?php echo e($data["menus"]); ?>

				</div> 
			</div>
		</div>
		<div class="col-sm-4">
			<div class="card text-center">
				<a href="<?php echo e(route('admin.users.index')); ?>" class="stretched-link"></a>
				<div class="card-header">
					<?php echo e(trans("web.users")); ?>

				</div>
				<div class="card-body">
					<?php echo e($data["users"]); ?>

				</div> 
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/admin/dashboard.blade.php ENDPATH**/ ?>