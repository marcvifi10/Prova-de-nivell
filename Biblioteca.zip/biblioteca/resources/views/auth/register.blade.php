@extends('layouts.app')

@include('frontend.register.plantilla')

