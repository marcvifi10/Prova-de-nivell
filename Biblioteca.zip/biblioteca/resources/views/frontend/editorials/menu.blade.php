
		<header>
			@include('frontend.editorials.capcalera')
		</header>
		<script src="js/menu.js"></script>
		@include('frontend.editorials.cos')
