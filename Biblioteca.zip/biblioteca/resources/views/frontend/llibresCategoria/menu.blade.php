
		<header>
			@include('frontend.llibresCategoria.capcalera')
		</header>
		<script src="js/menu.js"></script>
		@include('frontend.llibresCategoria.cos')
