
							<br>
                            <font size="4">
							    <strong>{{ $llibres->nom }}</strong>
                            </font>
							<br>
							<font size="4">
							    <strong>{{ $llibres->autor }}</strong>
                            </font>
							<br>
							<font size="4">
							    <strong>{{ $llibres->editorial }}</strong>
                            </font>
							<br>
							<font size="4">
							    <strong>{{ $llibres->preu }}</strong>
                            </font>