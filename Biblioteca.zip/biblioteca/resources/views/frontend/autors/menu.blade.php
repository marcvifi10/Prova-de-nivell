
		<header>
			@include('frontend.autors.capcalera')
		</header>
		<script src="js/menu.js"></script>
		@include('frontend.autors.cos')
